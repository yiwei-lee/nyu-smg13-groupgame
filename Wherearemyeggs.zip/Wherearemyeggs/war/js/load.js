var levelInfo = new Array();
var i = 0;

//theme 1
levelInfo[i] = new Array();
levelInfo[i][0] = new Array("Let the Eggs fall and collect Candy!", 800, 450);
levelInfo[i][1] = new Array("Bring the balls to the right side!", 800, 450);
levelInfo[i][2] = new Array("You can manipulate the Egg itselve here - guide its way through the maze!", 800, 450);
levelInfo[i][3] = new Array("This one is not easy - So it's enough to throw two Eggs into the Basket on the top right!", 800, 450);
levelInfo[i][4] = new Array("Use the outer Box to free the Eggs!", 800, 450);
levelInfo[i][5] = new Array("You can neither use the Wagon nor the balls themeselves. Bring the Eggs to the hole on the bottom right!!", 800, 450);
levelInfo[i][6] = new Array("You have to get the Eggs in the Pit in the middle!", 800, 450);
levelInfo[i][7] = new Array("Bring the Eggs to the Baskets of your choosing!", 800, 450);
levelInfo[i][8] = new Array("You can only use the Companion Cube to get the Eggs across the two holes!", 800, 450);

//theme 2
levelInfo[1] = new Array();
levelInfo[1][0] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][1] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][2] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][3] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][4] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][5] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][6] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][7] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[1][8] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);


//theme 3
i = 2;
levelInfo[i] = new Array();
levelInfo[i][0] = new Array("", 800, 450);
levelInfo[i][1] = new Array("", 800, 450);
levelInfo[i][2] = new Array("", 800, 450);
levelInfo[i][3] = new Array("", 800, 450);
levelInfo[i][4] = new Array("", 800, 450);
levelInfo[i][5] = new Array("", 800, 450);
levelInfo[i][6] = new Array("", 800, 450);
levelInfo[i][7] = new Array("", 800, 450);
levelInfo[i][8] = new Array("", 800, 450);

//theme 4
levelInfo[3] = new Array();
levelInfo[3][0] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][1] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][2] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][3] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][4] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][5] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][6] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][7] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);
levelInfo[3][8] = new Array("Fry all the eggs(rainbow) by connecting the eggs and plug(cyan) using blocks(green)", 800, 450);

//theme 5
i=4;
levelInfo[i] = new Array();
levelInfo[i][0] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][1] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][2] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][3] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][4] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][5] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][6] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][7] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);
levelInfo[i][8] = new Array("Move egg by tapping to left or right (click or touch). Speed is controlled by distance of tap from egg. Do not drag!", 800, 450);

//theme 6
levelInfo[5] = new Array();
levelInfo[5][0] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][1] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][2] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][3] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][4] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][5] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][6] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][7] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);
levelInfo[5][8] = new Array("Right Click in the transparent red area to create an angry bird !!!!Click or drag on the ice to cut it!!!!Crash into as many as easter bunny as possible!!!", 800, 600);


