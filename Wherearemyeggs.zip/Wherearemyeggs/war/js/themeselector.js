$( document ).delegate("#levelselectorpage", "pageshow", function() {	
	
});