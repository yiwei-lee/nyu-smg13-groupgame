function level4()	{
	daniel_level=4;
	//daniel_timer=3000+(daniel_level*1000);
	daniel_timer=10000;
	daniel_init();
}