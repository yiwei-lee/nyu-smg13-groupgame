function level6()	{
	daniel_level=6;
	//daniel_timer=3000+(daniel_level*1000);
	daniel_timer=10000;daniel_timer=3000+(daniel_level*1000);
	daniel_init();
}