function level10()	{
	daniel_level=10;
	//daniel_timer=3000+(daniel_level*1000);
	daniel_timer=10000;
	daniel_init();
}