var level9scene = 
{
	"allowSleep" : true,
	"autoClearForces" : true,
	"body" : 
	[
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5484778881072998, 0.5, -0.5, -0.4515221118927002 ],
							"y" : [ -11.79534244537354, 0.5, 0.5, -11.79534244537354 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 20.02152633666992,
				"y" : 12.27951908111572
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5484778881072998, 0.5, -0.5, -0.4515221118927002 ],
							"y" : [ -11.79534244537354, 0.5, 0.5, -11.79534244537354 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 0.0001668930053710938,
				"y" : 12.35219955444336
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture0",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : 
							[
								4.393985748291016,
								2.840215682983398,
								1.182930946350098,
								-2.196987152099609,
								-0.4592914581298828,
								1.357826232910156,
								2.940149307250977,
								4.014105796813965
							],
							"y" : 
							[
								0.0,
								1.791323661804199,
								2.729869842529297,
								3.805296897888184,
								-4.369909286499023,
								-4.178916931152344,
								-3.265359163284302,
								-1.787192106246948
							]
						}
					}
				},
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture0",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : 
							[
								-0.4592914581298828,
								-2.196987152099609,
								-3.554802417755127,
								-4.297955989837646,
								-4.297955989837646,
								-3.554797172546387,
								-2.196987152099609
							],
							"y" : 
							[
								-4.369909286499023,
								3.805296897888184,
								2.582716941833496,
								0.9135627746582031,
								-0.9135627746582031,
								-2.582716941833496,
								-3.805299758911133
							]
						}
					}
				},
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture0",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 1.489429473876953, -2.196987152099609, 1.182930946350098 ],
							"y" : [ 5.019479751586914, 3.805296897888184, 2.729869842529297 ]
						}
					}
				},
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture0",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 4.393985748291016, 4.014105796813965, 2.840215682983398 ],
							"y" : [ 0.0, 1.787189483642578, 1.791323661804199 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body0",
			"position" : 
			{
				"x" : 13.39107704162598,
				"y" : 5.258744239807129
			},
			"type" : 0
		},
		
		{
			"angle" : -3.342091083526611,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.4988965988159180, 0.06420135498046875, -0.5, -0.5011034011840820 ],
							"y" : [ -2.713421821594238, -0.5504704713821411, 0.5, -2.713421821594238 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 2.907616138458252,
				"y" : 1.673012256622314
			},
			"type" : 0
		},
		
		{
			"angle" : -0.1662202477455139,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : 
							[
								0.4696783125400543,
								0.2581459879875183,
								-0.1281171143054962,
								-0.5303217172622681
							],
							"y" : 
							[
								-1.960049510002136,
								0.4975697398185730,
								0.5023376345634460,
								-1.960049510002136
							]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"massData-I" : 2.303705453872681,
			"massData-center" : 
			{
				"x" : 0.01015327312052250,
				"y" : -0.9114870429039001
			},
			"massData-mass" : 1.705333232879639,
			"name" : "bolt",
			"position" : 
			{
				"x" : 2.364582061767578,
				"y" : 3.279860496520996
			},
			"type" : 2
		},
		
		{
			"angle" : -0.3487707972526550,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"circle" : 
					{
						"center" : 
						{
							"x" : -9.536743164062500e-07,
							"y" : 9.536743164062500e-07
						},
						"radius" : 0.6178193092346191
					},
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture8"
				}
			],
			"linearVelocity" : 0,
			"massData-I" : 0.2288578450679779,
			"massData-center" : 
			{
				"x" : -9.536743164062500e-07,
				"y" : 9.536743164062500e-07
			},
			"massData-mass" : 1.199148178100586,
			"name" : "body7",
			"position" : 
			{
				"x" : 2.742863655090332,
				"y" : 5.137312889099121
			},
			"type" : 2
		},
		
		{
			"angle" : -3.342091083526611,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, -0.07935169339179993, -0.5011034011840820, 0.4988965988159180 ],
							"y" : [ 0.5, -0.4180991649627686, -2.713421821594238, -2.713421821594238 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 1.218462944030762,
				"y" : 2.050895690917969
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture5",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, -2.185569947243948e-08, -0.5, 5.962439875162318e-09 ],
							"y" : [ 0.0, 0.5, -4.371139894487897e-08, -0.5 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body5",
			"position" : 
			{
				"x" : 20.0,
				"y" : 0
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture4",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, 0.5, -0.5, -0.5 ],
							"y" : [ -0.5, 0.5, 0.5, -0.5 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body4",
			"position" : 
			{
				"x" : 0,
				"y" : 13.33300018310547
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture3",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, 0.5, -0.5, -0.5 ],
							"y" : [ -0.5, 0.5, 0.5, -0.5 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body3",
			"position" : 
			{
				"x" : 20.0,
				"y" : 13.33300018310547
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture2",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, 0.5, -0.5, -0.5 ],
							"y" : [ -0.5, 0.5, 0.5, -0.5 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body2",
			"position" : 0,
			"type" : 0
		},
		
		{
			"angle" : -1.562889575958252,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5, -0.5, -0.5011034011840820, 0.4988965988159180 ],
							"y" : [ 0.5, 0.5, -2.713421821594238, -2.713421821594238 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 3.396842956542969,
				"y" : 0.6803579330444336
			},
			"type" : 0
		},
		
		{
			"angle" : 0,
			"angularVelocity" : 0,
			"awake" : true,
			"fixture" : 
			[
				
				{
					"density" : 1,
					"friction" : 0.2,
					"name" : "fixture6",
					"polygon" : 
					{
						"vertices" : 
						{
							"x" : [ 0.5484778881072998, 0.5, -0.5, -0.4515221118927002 ],
							"y" : [ -11.79534244537354, 0.5, 0.5, -11.79534244537354 ]
						}
					}
				}
			],
			"linearVelocity" : 0,
			"name" : "body6",
			"position" : 
			{
				"x" : 0.0001668930053710938,
				"y" : 12.35219955444336
			},
			"type" : 0
		}
	],
	"collisionbitplanes" : 
	{
		"names" : 
		[
			"bitplane1",
			"bitplane2",
			"bitplane3",
			"bitplane4",
			"bitplane5",
			"bitplane6",
			"bitplane7",
			"bitplane8",
			"bitplane9",
			"bitplane10",
			"bitplane11",
			"bitplane12",
			"bitplane13",
			"bitplane14",
			"bitplane15",
			"bitplane16",
			"bitplane17",
			"bitplane18",
			"bitplane19",
			"bitplane20",
			"bitplane21",
			"bitplane22",
			"bitplane23",
			"bitplane24",
			"bitplane25",
			"bitplane26",
			"bitplane27",
			"bitplane28",
			"bitplane29",
			"bitplane30",
			"bitplane31",
			"bitplane32"
		]
	},
	"continuousPhysics" : true,
	"gravity" : 
	{
		"x" : 0,
		"y" : -10
	},
	"positionIterations" : 3,
	"stepsPerSecond" : 60.0,
	"subStepping" : false,
	"velocityIterations" : 8,
	"warmStarting" : true
}
